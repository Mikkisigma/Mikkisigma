import cv2
import numpy as np
import time

def main():
    # Last bilklassifikatoren
    car_cascade = cv2.CascadeClassifier('cars.xml')
    if car_cascade.empty():
        print("Kunne ikke laste cars.xml")
        return

    # Åpne kamera
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Kunne ikke åpne kamera")
        return

    # Sett opp kamera (lavere oppløsning for bedre ytelse)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)
  

    # Definer gult fargeområde (HSV)
    lower_yellow = np.array([20, 100, 100])
    upper_yellow = np.array([35, 255, 255])

    while True:
        start_time = time.time()
        
        # Les bilde
        ret, frame = cap.read()
        if not ret:
            break

        # Resize for raskere behandling
        frame = cv2.resize(frame, (500, 500))
        
        # Konverter til HSV for fargedeteksjon
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        
        # Lag maske for gule farger
        yellow_mask = cv2.inRange(hsv, lower_yellow, upper_yellow)
        
        # Finn konturer i den gule masken
        contours, _ = cv2.findContours(yellow_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # Behandle hver kontur
        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area < 500:  # Ignorer små områder
                continue
                
            x, y, w, h = cv2.boundingRect(cnt)
            
            # Sjekk om dette kan være en bil (bredde/høyde-forhold)
            aspect_ratio = w / float(h)
            if 1.5 < aspect_ratio < 4.0:
                # Tegn boks rundt bilen
                cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 255), 2)
                cv2.putText(frame, 'Gul bil', (x, y-10), 
                          cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)

        # Beregn og vis FPS
        fps = 1.0 / (time.time() - start_time)
        cv2.putText(frame, f"FPS: {int(fps)}", (10, 20), 
                  cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)
        
        # Vis resultatet
        cv2.imshow('Gule biler', frame)
        
        # Avslutt med 'q'
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()